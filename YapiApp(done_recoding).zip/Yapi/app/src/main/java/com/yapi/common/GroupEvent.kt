package com.yapi.common

data class GroupEvent (var type:Int,var screenName:String)