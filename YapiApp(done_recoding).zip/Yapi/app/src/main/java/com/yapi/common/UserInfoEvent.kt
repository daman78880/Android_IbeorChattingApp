package com.yapi.common

data class UserInfoEvent (var type:Int,var name:String)