package com.yapi.views.menu_screen

data class PojoCustomerList(val img:String,val name:String,var onlineStatus:Boolean,var unSeenMsgCount:Int,var selectedStatus:Boolean=false)
