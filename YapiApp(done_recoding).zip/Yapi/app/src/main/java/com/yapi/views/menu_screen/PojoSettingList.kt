package com.yapi.views.menu_screen

data class PojoSettingList(var title:String,var selectedStatus:Boolean)