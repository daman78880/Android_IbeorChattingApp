package com.yapi.views.chat.chatUserInfo

import com.yapi.recycleradapter.AbstractModel

class TempModel (var name:String): AbstractModel()