package com.yapi.views.search_result

//data class PojoTabSearchResult(val title:String,var notificationCount:Int=0,var selected:Int=0)
data class PojoTabSearchResult(val title:String,var notificationCount:Int=0,var selected:Boolean=false)
