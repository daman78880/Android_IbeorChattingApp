package com.yapi.views.group_info.add_group_members

data class PojoGroupMembers(val name:String,val designation:String)