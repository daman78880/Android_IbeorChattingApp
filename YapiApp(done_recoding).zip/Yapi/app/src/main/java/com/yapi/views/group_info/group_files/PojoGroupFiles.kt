package com.yapi.views.group_info.group_files

data class PojoGroupFiles(val fileName:String,val fileSize:String,val fileSharedBy:String)
