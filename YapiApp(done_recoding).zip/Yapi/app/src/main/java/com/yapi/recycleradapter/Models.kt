package com.yapi.recycleradapter


data class DummyModel(var isPast: Boolean = false) : AbstractModel()

