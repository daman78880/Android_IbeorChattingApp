package com.yapi.common

data class MyMessageEvent (var type:Int,var screenName:String)