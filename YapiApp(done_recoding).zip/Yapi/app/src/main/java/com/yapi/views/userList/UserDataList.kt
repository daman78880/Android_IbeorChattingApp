package com.yapi.views.userList

data class UserDataList(var name:String,var isCheck:Boolean?=false)